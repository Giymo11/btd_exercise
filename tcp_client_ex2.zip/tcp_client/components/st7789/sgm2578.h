#ifndef MAIN_SGM2578_H_
#define MAIN_SGM2578_H_

void sgm2578_Enable(int gpio);

#endif
